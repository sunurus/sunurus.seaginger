"""CaptainKey KO: a Korean-first Windows configurator for CaptainKey v01.

SPDX-License-Identifier: GPL-3.0-only
"""

from __future__ import annotations

from pathlib import Path
from copy import deepcopy
import queue
import sys
import threading
import tkinter as tk
from tkinter import colorchooser, messagebox

import customtkinter as ctk
from serial.tools import list_ports

from protocol import (
    DeviceConfig, KEY_CHOICES, KEY_MODES, LIGHT_MODES, KeySettings,
    LightingSettings, SerialDevice, VALUE_TO_KEY, key_commands, lighting_commands,
)


ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

BG = "#EAEAEA"
NAV = "#E1E1E1"
CARD = "#FFFFFF"
CARD_LIGHT = "#F4F4F4"
BORDER = "#252525"
TEXT = "#050505"
MUTED = "#111111"
ACCENT = "#F00070"
ACCENT_HOVER = "#C00056"
MINT = "#007F70"
DANGER = "#C91B47"

MODE_LABELS = list(KEY_MODES.values())
LIGHT_LABELS = list(LIGHT_MODES.values())
PRESETS = [
    ("빨강", "#FF0000"), ("주황", "#FF8000"),
    ("노랑", "#FFFF00"), ("초록", "#00FF00"),
    ("파랑", "#0000FF"), ("보라", "#8000FF"),
]


def resource_path(name: str) -> Path:
    root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return root / name


class SerialWorker:
    """One serial-I/O thread; never read or write a port on the UI thread."""

    def __init__(self):
        self.pending: queue.Queue = queue.Queue()
        self.events: queue.Queue = queue.Queue()
        self.revisions = {"lighting": 0, "key1": 0, "key2": 0}
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def submit(self, task: str, payload=None):
        revision = 0
        if task == "restore":
            # Supersede stale live-update jobs that have not started yet.
            for name in self.revisions:
                self.revisions[name] += 1
        elif task in self.revisions:
            self.revisions[task] += 1
            revision = self.revisions[task]
        self.pending.put((task, payload, revision))

    def shutdown(self):
        self.submit("shutdown")

    def _run(self):
        device = None
        while True:
            task, payload, revision = self.pending.get()
            if task == "shutdown":
                if device:
                    try:
                        device.close()
                    except Exception:
                        pass
                break
            if task in self.revisions and revision != self.revisions[task]:
                continue
            try:
                if task == "connect":
                    if device:
                        device.close()
                    device = SerialDevice(payload)
                    config = device.read_config()
                    self.events.put(("connected", (payload, config)))
                elif task == "disconnect":
                    if device:
                        device.close()
                    device = None
                    self.events.put(("disconnected", None))
                elif device is None:
                    self.events.put(("error", "장치가 연결되지 않았습니다."))
                elif task == "read":
                    self.events.put(("config", device.read_config()))
                elif task == "restore":
                    generation, snapshot, restore_lighting, restore_keys, restore_double = payload
                    # A normal read returns the currently active RAM settings.
                    # Roll back only edited fields, avoiding unnecessary USB writes.
                    if restore_lighting:
                        device.send(lighting_commands(snapshot.lighting))
                    for which in restore_keys:
                        device.send(key_commands(which, snapshot.single if which == 1 else snapshot.double))
                    if restore_double:
                        device.send([(4, 2 if snapshot.double_click_enabled else 0)])
                    self.events.put(("restored", (generation, device.read_config())))
                elif task == "lighting":
                    device.send(lighting_commands(payload))
                elif task == "key1":
                    device.send(key_commands(1, payload))
                elif task == "key2":
                    device.send(key_commands(2, payload))
                elif task == "double_enabled":
                    device.send([(4, 2 if payload else 0)])
                elif task == "save":
                    device.save()
                    self.events.put(("saved", payload))
            except Exception as exc:
                if device:
                    try:
                        device.close()
                    except Exception:
                        pass
                    device = None
                self.events.put(("error", str(exc)))
                self.events.put(("disconnected", None))


class CaptainKeyKO(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("KEY2PLAY // UFO RETRO EDITION")
        self.geometry("1140x760")
        self.minsize(990, 680)
        self.configure(fg_color=BG)
        if sys.platform == "win32" and resource_path("icon.ico").exists():
            self.iconbitmap(str(resource_path("icon.ico")))

        self.worker = SerialWorker()
        self.connected = False
        self.loading = False
        self.port_map: dict[str, str] = {}
        self.active_page = "lighting"
        self.dirty_lighting = False
        self.dirty_keys: set[int] = set()
        self.dirty_double = False
        self.saved_config: DeviceConfig | None = None
        self.restoring = False
        self.saving = False
        self.edit_generation = 0
        self.apply_timer = None
        self.key_timers = {1: None, 2: None}

        self.lighting_vars = {
            "red": tk.IntVar(value=255), "green": tk.IntVar(value=255),
            "blue": tk.IntVar(value=255), "brightness": tk.IntVar(value=180),
            "step": tk.IntVar(value=1), "interval": tk.IntVar(value=30),
        }
        self.lighting_mode = tk.StringVar(value=LIGHT_LABELS[0])
        self.key_modes = {1: tk.StringVar(value=MODE_LABELS[0]), 2: tk.StringVar(value=MODE_LABELS[0])}
        self.key_values = {
            number: [tk.StringVar(value="없음") for _ in range(5)] for number in (1, 2)
        }
        self.key_text = {1: tk.StringVar(), 2: tk.StringVar()}
        self.double_enabled = tk.BooleanVar(value=True)
        self.value_labels = {}
        self.slider_rows = {}
        self.key_widgets = {}
        self.nav_buttons = {}
        self.pages = {}

        self._build_shell()
        self._build_lighting()
        self._build_keys(1)
        self._build_keys(2)
        self._build_about()
        self.show_page("lighting")
        self.refresh_ports()
        self._refresh_preview()
        self.after(70, self._poll_events)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _label(self, parent, text, size=13, color=MUTED, weight="normal", **kwargs):
        return ctk.CTkLabel(parent, text=text, text_color=color,
                            font=ctk.CTkFont(family="Consolas", size=max(13, size), weight="bold"), **kwargs)

    def _button(self, parent, text, command, *, width=110, accent=True, **kwargs):
        return ctk.CTkButton(
            parent, text=text, width=width, height=42, corner_radius=0,
            fg_color=ACCENT if accent else CARD_LIGHT,
            hover_color=ACCENT_HOVER if accent else "#DDDDDD",
            border_width=2, border_color="#222222",
            text_color="#FFFFFF" if accent else TEXT, font=ctk.CTkFont(family="Consolas", size=13, weight="bold"),
            command=command, **kwargs,
        )

    def _card(self, parent, **kwargs):
        return ctk.CTkFrame(parent, fg_color=CARD, corner_radius=0,
                            border_color=BORDER, border_width=2, **kwargs)

    def _build_shell(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        nav = ctk.CTkFrame(self, width=222, fg_color=NAV, corner_radius=0)
        nav.grid(row=0, column=0, sticky="nsew")
        nav.grid_propagate(False)
        logo = ctk.CTkFrame(nav, fg_color="#F00070", width=43, height=43, corner_radius=0, border_width=2, border_color="#111111")
        logo.pack(anchor="w", padx=22, pady=(32, 10))
        logo.pack_propagate(False)
        self._label(logo, "C", size=23, color="#FFFFFF", weight="bold").place(relx=.5, rely=.5, anchor="center")
        self._label(nav, "KEY2PLAY", size=21, color=TEXT, weight="bold").pack(anchor="w", padx=23)
        self._label(nav, "UFO", size=19, color=ACCENT, weight="bold").pack(anchor="w", padx=23, pady=(4, 28))
        ctk.CTkFrame(nav, height=5, fg_color="#B6FF24", corner_radius=0).pack(fill="x", padx=22, pady=(0, 18))
        self._label(nav, "설정 메뉴", size=11, weight="bold").pack(anchor="w", padx=24, pady=(0, 12))

        for page, text in [
            ("lighting", "  ◉  LED 조명"), ("key1", "  ⌨  한 번 클릭"),
            ("key2", "  ⌨  두 번 클릭"), ("about", "  ⓘ  도움말 · 정보"),
        ]:
            btn = ctk.CTkButton(
                nav, text=text, anchor="w", height=47, corner_radius=0,
                fg_color="transparent", hover_color="#FFD1E7", text_color=MUTED,
                font=ctk.CTkFont(family="Consolas", size=13, weight="bold"),
                command=lambda p=page: self.show_page(p),
            )
            btn.pack(fill="x", padx=15, pady=4)
            self.nav_buttons[page] = btn

        ctk.CTkFrame(nav, height=1, fg_color=BORDER).pack(side="bottom", fill="x", padx=22, pady=15)
        self._label(nav, "CH552 · CaptainKey v01 호환", size=11).pack(side="bottom", padx=22, pady=(0, 8), anchor="w")

        content = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        content.grid(row=0, column=1, sticky="nsew")
        content.grid_columnconfigure(0, weight=1)
        content.grid_rowconfigure(1, weight=1)

        titlebar = ctk.CTkFrame(content, fg_color="#0C167E", corner_radius=0, height=34)
        titlebar.grid(row=0, column=0, sticky="new", padx=27, pady=(12, 0))
        titlebar.grid_propagate(False)
        self._label(titlebar, "▣  KEY2PLAY.EXE  //  UFO CONTROL PANEL", size=13, color="#FFFFFF").pack(side="left", padx=12)
        header = self._card(content)
        header.grid(row=0, column=0, sticky="ew", padx=27, pady=(46, 14))
        titlebar.lift()
        header.grid_columnconfigure(1, weight=1)
        top_title = ctk.CTkFrame(header, fg_color="transparent")
        top_title.grid(row=0, column=0, sticky="w", padx=20, pady=19)
        self._label(top_title, "장치 연결", size=14, color=TEXT, weight="bold").pack(anchor="w")
        self.state_label = self._label(top_title, "연결 대기 중", size=11)
        self.state_label.pack(anchor="w", pady=(4, 0))

        controls = ctk.CTkFrame(header, fg_color="transparent")
        controls.grid(row=0, column=1, sticky="e", padx=18)
        self.port_menu = ctk.CTkOptionMenu(
            controls, values=["COM 포트 검색 중"], width=210, height=38,
            fg_color="#FFFFFF", button_color="#B6FF24", button_hover_color="#8BE800",
            dropdown_fg_color="#FFFFFF", text_color=TEXT, dropdown_text_color=TEXT,
            font=ctk.CTkFont(family="Consolas", size=13, weight="bold"),
        )
        self.port_menu.pack(side="left", padx=(0, 8))
        self._button(controls, "새로고침", self.refresh_ports, width=82, accent=False).pack(side="left", padx=3)
        self.connect_button = self._button(controls, "연결", self.toggle_connection, width=84)
        self.connect_button.pack(side="left", padx=3)

        self.page_host = ctk.CTkFrame(content, fg_color="transparent")
        self.page_host.grid(row=1, column=0, sticky="nsew", padx=27)
        self.page_host.grid_rowconfigure(0, weight=1)
        self.page_host.grid_columnconfigure(0, weight=1)

        bottom = self._card(content)
        bottom.grid(row=2, column=0, sticky="ew", padx=27, pady=(14, 22))
        bottom.grid_columnconfigure(0, weight=1)
        self.toast = self._label(bottom, "장치를 연결하면 설정을 실시간으로 적용할 수 있습니다.", size=12)
        self.toast.grid(row=0, column=0, sticky="w", padx=18, pady=13)
        self.reload_button = self._button(bottom, "설정 다시 읽기", self.reload, width=122, accent=False)
        self.reload_button.grid(row=0, column=1, padx=6, pady=10)
        self.save_button = self._button(bottom, "기기에 저장", self.save_config, width=118)
        self.save_button.grid(row=0, column=2, padx=(6, 15), pady=10)

    def _new_page(self, name):
        page = ctk.CTkScrollableFrame(self.page_host, fg_color="transparent", corner_radius=0)
        page.grid(row=0, column=0, sticky="nsew")
        page.grid_remove()
        self.pages[name] = page
        return page

    def _page_heading(self, parent, title, subtitle):
        self._label(parent, title, size=26, color=TEXT, weight="bold").pack(anchor="w", pady=(2, 5))
        self._label(parent, subtitle, size=12).pack(anchor="w", pady=(0, 20))

    def _build_lighting(self):
        page = self._new_page("lighting")
        self._page_heading(page, "LED 조명", "RGB 색상과 애니메이션 효과를 실시간으로 설정하세요.")

        preview = self._card(page)
        preview.pack(fill="x", pady=(0, 14))
        row = ctk.CTkFrame(preview, fg_color="transparent")
        row.pack(fill="x", padx=22, pady=21)
        swatch_box = ctk.CTkFrame(row, fg_color=CARD_LIGHT, width=112, height=112, corner_radius=0)
        swatch_box.pack(side="left", padx=(0, 20))
        swatch_box.pack_propagate(False)
        self.preview_swatch = ctk.CTkFrame(swatch_box, fg_color="#FFFFFF", width=78, height=78, corner_radius=0)
        self.preview_swatch.place(relx=.5, rely=.5, anchor="center")
        copy = ctk.CTkFrame(row, fg_color="transparent")
        copy.pack(side="left", fill="both", expand=True)
        self.preview_title = self._label(copy, "현재 색상", size=13, color=TEXT, weight="bold")
        self.preview_title.pack(anchor="w")
        self.hex_label = self._label(copy, "#FFFFFF", size=27, color=TEXT, weight="bold")
        self.hex_label.pack(anchor="w", pady=(4, 3))
        self._label(copy, "미리보기는 화면 색상이므로 실제 LED와 차이가 있을 수 있습니다.", size=10).pack(anchor="w")
        self._button(row, "색상 선택", self.choose_color, width=112, accent=False).pack(side="right")

        mode_card = self._card(page)
        mode_card.pack(fill="x", pady=(0, 14))
        self._label(mode_card, "조명 모드", size=15, color=TEXT, weight="bold").pack(anchor="w", padx=22, pady=(18, 12))
        self.mode_control = ctk.CTkSegmentedButton(
            mode_card, values=LIGHT_LABELS, variable=self.lighting_mode,
            selected_color="#FFE0EC", selected_hover_color="#FFD0E2",
            unselected_color=CARD_LIGHT, unselected_hover_color="#E5E5E5",
            text_color="#050505", text_color_disabled="#050505",
            font=ctk.CTkFont(family="Consolas", size=12, weight="bold"),
            command=lambda value: self._on_lighting_change(), height=39,
        )
        self.mode_control.pack(fill="x", padx=22, pady=(0, 20))

        color_card = self._card(page)
        self.color_card = color_card
        color_card.pack(fill="x", pady=(0, 14))
        self._label(color_card, "RGB · 밝기", size=15, color=TEXT, weight="bold").pack(anchor="w", padx=22, pady=(19, 7))
        color_rows = ctk.CTkFrame(color_card, fg_color="transparent")
        color_rows.pack(fill="x", padx=22, pady=(0, 16))
        for name, title in [("red", "빨강 R"), ("green", "초록 G"), ("blue", "파랑 B"), ("brightness", "밝기 V")]:
            self._slider_row(color_rows, name, title, 0, 255)

        self.motion_card = self._card(page)
        self.motion_card.pack(fill="x", pady=(0, 14))
        self._label(self.motion_card, "효과 속도", size=15, color=TEXT, weight="bold").pack(anchor="w", padx=22, pady=(19, 7))
        motion_rows = ctk.CTkFrame(self.motion_card, fg_color="transparent")
        motion_rows.pack(fill="x", padx=22, pady=(0, 16))
        self._slider_row(motion_rows, "step", "변화 폭", 1, 50)
        self._slider_row(motion_rows, "interval", "변화 간격 (ms)", 5, 200)

        preset_card = self._card(page)
        self.preset_card = preset_card
        preset_card.pack(fill="x", pady=(0, 10))
        self._label(preset_card, "빠른 색상 프리셋", size=15, color=TEXT, weight="bold").pack(anchor="w", padx=22, pady=(19, 13))
        chips = ctk.CTkFrame(preset_card, fg_color="transparent")
        chips.pack(fill="x", padx=22, pady=(0, 20))
        for name, color in PRESETS:
            ctk.CTkButton(
                chips, text=name, width=102, height=36, corner_radius=0,
                fg_color=color, hover_color=color, border_width=2,
                border_color="#273B59", text_color="#FFFFFF" if color in ("#0000FF", "#8000FF", "#FF0000") else "#111827",
                command=lambda col=color: self._set_preset(col),
            ).pack(side="left", padx=(0, 8))
        self._update_motion_visibility()

    def _slider_row(self, parent, name, title, minimum, maximum):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=8)
        self._label(row, title, size=12, color=TEXT, weight="bold", width=140, anchor="w").pack(side="left")
        scale = ctk.CTkSlider(
            row, from_=minimum, to=maximum, number_of_steps=maximum - minimum,
            progress_color=ACCENT, button_color="#F00070", button_hover_color=TEXT,
            fg_color="#AFAFAF", variable=self.lighting_vars[name],
            command=lambda _v, k=name: self._on_lighting_change(k),
        )
        scale.pack(side="left", fill="x", expand=True, padx=13)
        label = self._label(row, str(self.lighting_vars[name].get()), size=13,
                            color=TEXT, weight="bold", width=50, anchor="e")
        label.pack(side="right")
        self.value_labels[name] = label
        self.slider_rows[name] = row

    def _build_keys(self, which):
        page = self._new_page(f"key{which}")
        # Summary sits to the right of the page title, not in a separate card.
        header = ctk.CTkFrame(page, fg_color="transparent")
        header.pack(fill="x", pady=(2, 20))
        heading = ctk.CTkFrame(header, fg_color="transparent")
        heading.pack(side="left", anchor="nw")
        self._label(heading, "한 번 클릭" if which == 1 else "두 번 클릭",
                    size=26, color=TEXT, weight="bold").pack(anchor="w")
        self._label(heading, "한 번 누를 때" if which == 1 else "두 번 누를 때",
                    size=12).pack(anchor="w", pady=(5, 0))
        summary_panel = ctk.CTkFrame(header, fg_color="#FFFFFF", corner_radius=0,
                                     border_width=2, border_color=BORDER)
        summary_panel.pack(side="right", anchor="ne", padx=(12, 0))
        self._label(summary_panel, "현재 실행 방식", size=12, color=TEXT,
                    weight="bold").pack(anchor="w", padx=14, pady=(8, 1))
        summary_value = self._label(summary_panel, "", size=14, color=TEXT,
                                    weight="bold", wraplength=350, justify="left")
        summary_value.pack(anchor="w", padx=14, pady=(0, 9))
        if which == 2:
            toggle_card = self._card(page)
            toggle_card.pack(fill="x", pady=(0, 14))
            toggle_row = ctk.CTkFrame(toggle_card, fg_color="transparent")
            toggle_row.pack(fill="x", padx=22, pady=18)
            labels = ctk.CTkFrame(toggle_row, fg_color="transparent")
            labels.pack(side="left", fill="x", expand=True)
            self._label(labels, "더블 클릭 기능", size=15, color=TEXT, weight="bold").pack(anchor="w")
            self._label(labels, "두 번 클릭 사용", size=11).pack(anchor="w", pady=(5, 0))
            ctk.CTkSwitch(toggle_row, text="", variable=self.double_enabled,
                          progress_color=ACCENT, button_color=TEXT,
                          command=self._on_double_toggle, width=54).pack(side="right")

        mode_card = self._card(page)
        mode_card.pack(fill="x", pady=(0, 14))
        self._label(mode_card, "01  실행 방식", size=17, color=TEXT, weight="bold").pack(anchor="w", padx=22, pady=(19, 7))
        mode = ctk.CTkSegmentedButton(
            mode_card, values=MODE_LABELS, variable=self.key_modes[which],
            selected_color="#FFE0EC", selected_hover_color="#FFD0E2",
            unselected_color=CARD_LIGHT, unselected_hover_color="#E5E5E5",
            text_color="#050505", text_color_disabled="#050505",
            font=ctk.CTkFont(family="Consolas", size=12, weight="bold"),
            command=lambda _v, n=which: self._on_key_change(n), height=39,
        )
        mode.pack(fill="x", padx=22, pady=(0, 16))
        help_label = self._label(mode_card, "", size=11)
        help_label.pack(anchor="w", padx=22, pady=(0, 19))

        input_card = self._card(page)
        input_card.pack(fill="x", pady=(0, 14))
        detail_title = self._label(input_card, "02  세부 설정", size=17, color=TEXT, weight="bold")
        detail_title.pack(anchor="w", padx=22, pady=(20, 6))
        combo_frame = ctk.CTkFrame(input_card, fg_color="transparent")
        combo_frame.pack(fill="x", padx=22, pady=(14, 24))
        menus = []
        for i in range(5):
            combo_frame.grid_columnconfigure(i, weight=1)
            col = ctk.CTkFrame(combo_frame, fg_color="transparent")
            col.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 5, 5 if i < 4 else 0))
            self._label(col, f"키 {i + 1}", size=11).pack(anchor="w", pady=(0, 6))
            menu = ctk.CTkOptionMenu(
                col, values=list(KEY_CHOICES), variable=self.key_values[which][i],
                width=120, height=38, fg_color="#FFFFFF", button_color="#B6FF24",
                button_hover_color="#8BE800", dropdown_fg_color="#FFFFFF", text_color=TEXT, dropdown_text_color=TEXT,
                font=ctk.CTkFont(family="Consolas", size=13, weight="bold"),
                command=lambda _value, n=which: self._on_key_change(n),
            )
            menu.pack(fill="x")
            menus.append(menu)

        text_frame = ctk.CTkFrame(input_card, fg_color="transparent")
        self._label(text_frame, "입력할 텍스트", size=12, color=TEXT, weight="bold").pack(anchor="w", pady=(0, 10))
        text_entry = ctk.CTkEntry(
            text_frame, textvariable=self.key_text[which], height=42, corner_radius=0,
            fg_color=CARD_LIGHT, border_color=BORDER, placeholder_text="Hello World",
            font=ctk.CTkFont(family="Consolas", size=13, weight="bold"),
        )
        text_entry.pack(fill="x")
        text_hint = self._label(text_frame, "최대 30자 · ASCII", size=11)
        text_hint.pack(anchor="w", pady=(8, 0))

        # Reference only: no change to key mapping or device communication.
        shortcut_card = self._card(page)
        shortcut_card.pack(fill="x", pady=(0, 14))
        self._label(shortcut_card, "자주 쓰는 단축키", size=15, color=TEXT,
                    weight="bold").pack(anchor="w", padx=22, pady=(17, 10))
        shortcut_columns = ctk.CTkFrame(shortcut_card, fg_color="transparent")
        shortcut_columns.pack(fill="x", padx=22, pady=(0, 18))
        shortcut_columns.grid_columnconfigure(0, weight=1)
        shortcut_columns.grid_columnconfigure(1, weight=1)
        examples = [
            ("문서 · 편집", [
                "Ctrl + C  복사",
                "Ctrl + V  붙여넣기",
                "Ctrl + X  잘라내기",
                "Ctrl + Z  실행 취소",
                "Ctrl + Y  다시 실행",
                "Ctrl + A  전체 선택",
                "Ctrl + S  저장",
                "Ctrl + F  찾기",
                "Ctrl + P  인쇄",
                "Ctrl + O  파일 열기",
            ]),
            ("브라우저 · 탭", [
                "Ctrl + T  새 탭",
                "Ctrl + W  현재 탭 닫기",
                "Ctrl + Shift + T  닫은 탭 복원",
                "Ctrl + Tab  다음 탭",
                "Ctrl + Shift + Tab  이전 탭",
                "Ctrl + L  주소창 선택",
                "Ctrl + R  새로고침",
                "Ctrl + N  새 창",
                "Ctrl + Shift + N  시크릿 창",
                "Ctrl + H  방문 기록",
                "Ctrl + J  다운로드 목록",
            ]),
            ("빠른 화면 전환 · 프라이버시", [
                "Alt + Tab  다른 창으로 전환",
                "Alt + Shift + Tab  이전 창으로 전환",
                "Win + D  바탕화면 보기 / 복귀",
                "Win + M  모든 창 최소화",
                "Win + Shift + M  최소화한 창 복원",
                "Win + L  화면 잠금",
                "Win + Tab  작업 보기",
                "Ctrl + W  브라우저 탭 닫기",
            ]),
            ("Windows · 빠른 실행", [
                "Win + E  파일 탐색기",
                "Win + R  실행 창",
                "Win + I  Windows 설정",
                "Win + V  클립보드 기록(설정 필요)",
                "Win + Space  입력 언어 전환",
                "Ctrl + Shift + Esc  작업 관리자",
                "Ctrl + Esc  시작 메뉴",
                "Alt + Space  창 메뉴",
                "Delete  선택 항목 삭제",
            ]),
            ("몰컴할 때 유용한 키", [
                "Alt + Tab  다른 창으로 빠르게 전환",
                "Win + D  바탕화면 바로 보기 / 복귀",
                "Win + L  컴퓨터 화면 잠금",
                "Ctrl + W  현재 브라우저 탭 닫기",
                "Alt + F4  현재 프로그램 창 닫기",
                "Win + M  열린 창 모두 최소화",
                "Win + Shift + M  최소화한 창 복원",
                "Ctrl + Shift + T  방금 닫은 탭 복구",
                "Win + Ctrl + D  새 가상 데스크톱 만들기",
                "Win + Ctrl + ←/→  가상 데스크톱 전환",
            ]),
        ]
        for index, (section, items) in enumerate(examples):
            column = ctk.CTkFrame(shortcut_columns, fg_color="transparent")
            column.grid(row=index // 2, column=index % 2, sticky="nw",
                        padx=(0, 12) if index % 2 == 0 else (12, 0), pady=(0, 22))
            self._label(column, section, size=13, color=TEXT,
                        weight="bold").pack(anchor="w", pady=(0, 8))
            self._label(column, "\n".join(items), size=12, color=TEXT,
                        weight="bold", justify="left").pack(anchor="w")

        self.key_widgets[which] = {
            "help": help_label, "combo": combo_frame, "menus": menus,
            "text": text_frame, "input_card": input_card, "hint": text_hint,
            "detail_title": detail_title, "combo_columns": [m.master for m in menus],
            "mode_card": mode_card, "mode_button": mode, "summary_panel": summary_panel,
            "text_entry": text_entry, "toggle_card": toggle_card if which == 2 else None,
            "shortcut_card": shortcut_card,
        }
        self.key_text[which].trace_add("write", lambda *_args, n=which: self._on_key_change(n))

        self.key_widgets[which]["summary"] = summary_value
        self._update_key_visibility(which)
        if which == 2:
            self._apply_double_ui_state()

    def _build_about(self):
        page = self._new_page("about")
        self._page_heading(page, "도움말 · 정보", "연결과 저장 방법, 펌웨어 호환성을 확인하세요.")
        for title, detail in [
            ("연결하기", "Key2Play를 USB로 연결 → 새로고침 → COM 포트 선택 → 연결. CaptainKey 원본 프로그램이나 웹 설정 페이지는 먼저 닫아 주세요."),
            ("실시간 적용", "연결 중 LED·키 입력을 바꾸면 장치의 RAM 설정이 업데이트됩니다. 연결을 끊으면 저장하지 않은 변경은 사라질 수 있습니다."),
            ("기기에 저장", "오른쪽 아래 [기기에 저장]을 누르면 EEPROM 저장 명령을 전송합니다. 펌웨어는 성공 확인 응답을 보내지 않습니다."),
            ("단축키 조합 방식", "'즉시 실행 조합'은 키를 순서대로 누른 직후 역순으로 해제합니다. '누르는 동안 조합'은 물리 버튼을 뗄 때 해제합니다."),
            ("한글 입력 안내", "일반 키 입력은 컴퓨터의 한/영 입력 상태를 따릅니다. 한글 입력 상태라면 대응하는 한글이 입력될 수 있습니다. 텍스트 자동 입력 모드는 별도 방식이며 지원 문자를 확인하세요."),
            ("호환 펌웨어", "CaptainKey v01 (CH552, USB CDC, 57,600bps)의 설정 인덱스를 기반으로 만들었습니다. 다른 펌웨어에서는 동작을 보장하지 않습니다."),
            ("오픈소스 · 라이선스", "CaptainKey KO는 Yamada-da/CaptainKey를 바탕으로 만든 GPL-3.0 한국어 프런트엔드입니다. 원본: github.com/Yamada-da/CaptainKey"),
        ]:
            card = self._card(page)
            card.pack(fill="x", pady=(0, 11))
            self._label(card, title, size=14, color=TEXT, weight="bold").pack(anchor="w", padx=20, pady=(16, 5))
            self._label(card, detail, size=12, wraplength=690, justify="left").pack(anchor="w", padx=20, pady=(0, 17))

    def show_page(self, name):
        for page_name, frame in self.pages.items():
            if page_name == name:
                frame.grid()
            else:
                frame.grid_remove()
            self.nav_buttons[page_name].configure(
                fg_color="#FFE4EF" if page_name == name else "transparent",
                text_color=TEXT if page_name == name else MUTED,
            )
        self.active_page = name

    def refresh_ports(self):
        current = self.port_menu.get()
        self.port_map = {}
        for port in list_ports.comports():
            display = f"{port.device}  |  {port.description[:27]}"
            self.port_map[display] = port.device
        choices = list(self.port_map) or ["연결 가능한 COM 포트 없음"]
        self.port_menu.configure(values=choices)
        self.port_menu.set(current if current in choices else choices[0])
        if not self.port_map:
            self._toast("COM 포트가 없습니다. USB 연결과 펌웨어를 확인해 주세요.")

    def toggle_connection(self):
        if self.connected:
            self._flush_edits()
            self.worker.submit("disconnect")
            self.state_label.configure(text="연결 해제 중…", text_color=MUTED)
            return
        display = self.port_menu.get()
        port = self.port_map.get(display)
        if not port:
            messagebox.showwarning("COM 포트 선택", "먼저 새로고침을 눌러 COM 포트를 선택해 주세요.")
            return
        self.state_label.configure(text=f"{port} 연결 중…", text_color=MUTED)
        self.connect_button.configure(state="disabled")
        self.worker.submit("connect", port)

    def reload(self):
        if not self.connected:
            self._toast("먼저 장치를 연결해 주세요.", warn=True)
            return
        if self.restoring or self.saving:
            self._toast("장치 작업이 끝난 뒤 다시 시도해 주세요.")
            return
        dirty = self.dirty_lighting or self.dirty_keys or self.dirty_double
        if dirty and not messagebox.askyesno(
            "설정 다시 읽기",
            "저장하지 않은 변경 사항을 취소하고, 기기 설정을 다시 불러올까요?",
        ):
            return
        self._cancel_edits()
        if dirty:
            if self.saved_config is None:
                self._toast("복원할 설정이 없습니다. 키링을 다시 연결해 주세요.", warn=True)
                return
            # Re-reading by itself would return the already modified RAM values.
            # Restore the snapshot first; do not write it to EEPROM.
            self.restoring = True
            self.reload_button.configure(state="disabled")
            self.save_button.configure(state="disabled")
            self.connect_button.configure(state="disabled")
            self.worker.submit("restore", (
                self.edit_generation,
                deepcopy(self.saved_config),
                bool(self.dirty_lighting),
                tuple(sorted(self.dirty_keys)),
                bool(self.dirty_double),
            ))
            self._toast("기기의 이전 설정을 복원하고 다시 읽는 중입니다…")
        else:
            self.worker.submit("read")
            self._toast("장치의 현재 설정을 읽는 중입니다…")

    def _toast(self, text, warn=False):
        self.toast.configure(text=text, text_color=DANGER if warn else MUTED)

    def _on_lighting_change(self, _which=None):
        self._refresh_preview()
        self._update_motion_visibility()
        if self.loading or self.restoring:
            return
        self.edit_generation += 1
        self.dirty_lighting = True
        self._toast("조명 설정을 변경했습니다. 기기에 저장하면 USB 재연결 후에도 유지돼요.")
        if self.apply_timer is not None:
            self.after_cancel(self.apply_timer)
        self.apply_timer = self.after(160, self._send_lighting)

    def _lighting_settings(self):
        mode = LIGHT_LABELS.index(self.lighting_mode.get())
        return LightingSettings(**{name: var.get() for name, var in self.lighting_vars.items()}, mode=mode)

    def _refresh_preview(self):
        r = self.lighting_vars["red"].get()
        g = self.lighting_vars["green"].get()
        b = self.lighting_vars["blue"].get()
        v = self.lighting_vars["brightness"].get() / 255
        color = f"#{int(r * v):02X}{int(g * v):02X}{int(b * v):02X}"
        self.preview_swatch.configure(fg_color=color)
        self.hex_label.configure(text=f"#{r:02X}{g:02X}{b:02X}")
        self.preview_title.configure(text="현재 색상 · 무지개 모드에서는 RGB값 무시" if self.lighting_mode.get() == LIGHT_LABELS[2] else "현재 색상")
        for name, label in self.value_labels.items():
            label.configure(text=str(self.lighting_vars[name].get()))

    def _update_motion_visibility(self):
        # RGB presets apply to fixed-color mode only; hide them for breathing/rainbow/off.
        fixed_mode = self.lighting_mode.get() == LIGHT_LABELS[0]
        if fixed_mode:
            if not self.preset_card.winfo_manager():
                self.preset_card.pack(fill="x", pady=(0, 10))
        else:
            self.preset_card.pack_forget()
        hue_mode = self.lighting_mode.get() == LIGHT_LABELS[2]
        for name in ("red", "green", "blue"):
            row = self.slider_rows[name]
            if hue_mode:
                row.pack_forget()
            elif not row.winfo_manager():
                row.pack(fill="x", pady=8, before=self.slider_rows["brightness"])
        if self.lighting_mode.get() == LIGHT_LABELS[0]:
            self.motion_card.pack_forget()
        elif not self.motion_card.winfo_manager():
            self.motion_card.pack(fill="x", pady=(0, 14), after=self.color_card)

    def _set_preset(self, value):
        self.lighting_mode.set(LIGHT_LABELS[0])
        for name, channel in zip(("red", "green", "blue"), (1, 3, 5)):
            self.lighting_vars[name].set(int(value[channel:channel + 2], 16))
        self._on_lighting_change()

    def choose_color(self):
        rgb = tuple(self.lighting_vars[k].get() for k in ("red", "green", "blue"))
        chosen = colorchooser.askcolor(color=rgb, parent=self, title="LED 색상 선택")
        if chosen[0]:
            for name, value in zip(("red", "green", "blue"), chosen[0]):
                self.lighting_vars[name].set(int(round(value)))
            self.lighting_mode.set(LIGHT_LABELS[0])
            self._on_lighting_change()

    def _send_lighting(self):
        self.apply_timer = None
        if not self.connected:
            return
        try:
            self.worker.submit("lighting", self._lighting_settings())
        except ValueError as exc:
            self._toast(str(exc), warn=True)

    def _key_settings(self, which):
        return KeySettings(
            mode=MODE_LABELS.index(self.key_modes[which].get()),
            keys=[KEY_CHOICES.get(v.get(), 0) if (MODE_LABELS.index(self.key_modes[which].get()) != 0 or i == 0) else 0 for i, v in enumerate(self.key_values[which])],
            text=self.key_text[which].get(),
        )

    def _update_key_visibility(self, which):
        ui = self.key_widgets[which]
        mode = MODE_LABELS.index(self.key_modes[which].get())
        titles = ["02  단일 키", "02  즉시 실행 조합", "02  누르는 동안 조합", "02  텍스트 입력"]
        if mode == 3:
            ui["combo"].pack_forget()
            ui["text"].pack(fill="x", padx=22, pady=(14, 24))
        else:
            ui["text"].pack_forget()
            ui["combo"].pack(fill="x", padx=22, pady=(14, 24))
            for i, col in enumerate(ui["combo_columns"]):
                if mode == 0 and i > 0:
                    col.grid_remove()
                else:
                    col.grid()
            for menu in ui["menus"]:
                menu.configure(state="normal")
        ui["hint"].configure(text=f"{len(self.key_text[which].get())}/30자 · 텍스트 자동 입력은 ASCII 기반")
        self._refresh_key_help_and_summary(which)
        if which == 2:
            self._apply_double_ui_state()

    def _update_key_summary(self, which):
        ui = self.key_widgets[which]
        if "summary" not in ui:
            return
        mode = MODE_LABELS.index(self.key_modes[which].get())
        if mode == 3:
            detail = self.key_text[which].get() or "(입력 없음)"
            detail = detail.replace("\n", " ")
            if len(detail) > 48:
                detail = detail[:48] + "…"
        else:
            keys = [v.get() for v in self.key_values[which]][:1 if mode == 0 else 5]
            detail = " + ".join(k for k in keys if k != "없음") or "(선택 없음)"
        ui["summary"].configure(text=f"{MODE_LABELS[mode]} : {detail}")

    def _set_widget_state_recursive(self, widget, enabled: bool):
        try:
            if hasattr(widget, "configure") and "state" in widget.configure():
                widget.configure(state="normal" if enabled else "disabled")
        except Exception:
            pass
        try:
            children = widget.winfo_children()
        except Exception:
            children = []
        for child in children:
            self._set_widget_state_recursive(child, enabled)

    def _apply_double_ui_state(self):
        ui = self.key_widgets.get(2)
        if not ui:
            return
        enabled = self.double_enabled.get()
        dim_card = "#ECECEC"
        dim_text = "#8A8F98"
        normal_card = CARD
        normal_text = TEXT

        if enabled:
            self._refresh_key_help_and_summary(2)
        else:
            ui["summary"].configure(text="OFF")
            ui["help"].configure(text="OFF")

        ui["summary"].configure(text_color=normal_text if enabled else dim_text)
        ui["summary_panel"].configure(fg_color="#FFFFFF" if enabled else "#F1F1F1",
                                      border_color=BORDER if enabled else "#B9BDC3")
        ui["help"].configure(text_color=normal_text if enabled else dim_text)

        for card_name in ("mode_card", "input_card", "shortcut_card"):
            ui[card_name].configure(fg_color=normal_card if enabled else dim_card,
                                    border_color=BORDER if enabled else "#B9BDC3")

        try:
            ui["mode_button"].configure(state="normal" if enabled else "disabled")
        except Exception:
            pass

        for menu in ui["menus"]:
            try:
                menu.configure(state="normal" if enabled else "disabled")
            except Exception:
                pass
        try:
            ui["text_entry"].configure(state="normal" if enabled else "disabled")
        except Exception:
            pass

        # Dim labels and auxiliary widgets for a stronger OFF feeling.
        self._set_widget_state_recursive(ui["combo"], enabled)
        self._set_widget_state_recursive(ui["text"], enabled)

        for key in ("detail_title", "hint"):
            ui[key].configure(text_color=normal_text if enabled else dim_text)
        for col in ui["combo_columns"]:
            for child in col.winfo_children():
                if hasattr(child, "configure"):
                    try:
                        child.configure(text_color=normal_text if enabled else dim_text)
                    except Exception:
                        pass

    def _refresh_key_help_and_summary(self, which):
        ui = self.key_widgets[which]
        mode = MODE_LABELS.index(self.key_modes[which].get())
        messages = [
            "키 하나를 누르고 있는 동안 유지",
            "여러 키를 짧게 누르고 자동으로 해제",
            "여러 키를 버튼에서 손을 뗄 때까지 유지",
            "설정한 문장을 자동으로 입력",
        ]
        if which == 2 and not self.double_enabled.get():
            ui["help"].configure(text="OFF")
            ui["summary"].configure(text="OFF")
        else:
            ui["help"].configure(text=messages[mode])
            self._update_key_summary(which)

    def _on_key_change(self, which):
        self._update_key_visibility(which)
        if self.loading or self.restoring:
            return
        self.edit_generation += 1
        self.dirty_keys.add(which)
        self._toast("설정 변경됨")
        if self.key_timers[which] is not None:
            self.after_cancel(self.key_timers[which])
        self.key_timers[which] = self.after(260, lambda n=which: self._send_keys(n))

    def _send_keys(self, which):
        self.key_timers[which] = None
        if not self.connected:
            return
        try:
            data = self._key_settings(which)
            key_commands(which, data)  # Validate before queueing to a worker.
            self.worker.submit(f"key{which}", data)
        except ValueError as exc:
            self._toast(str(exc), warn=True)

    def _on_double_toggle(self):
        if self.loading or self.restoring:
            return
        self.edit_generation += 1
        self.dirty_double = True
        self._apply_double_ui_state()
        if self.connected:
            self.worker.submit("double_enabled", self.double_enabled.get())
        self._toast("더블 클릭 활성화 설정을 변경했습니다. 기기에 저장해 주세요.")

    def _cancel_edits(self):
        if self.apply_timer is not None:
            self.after_cancel(self.apply_timer)
            self.apply_timer = None
        for which in (1, 2):
            if self.key_timers[which] is not None:
                self.after_cancel(self.key_timers[which])
                self.key_timers[which] = None

    def _flush_edits(self):
        self._cancel_edits()
        if self.dirty_lighting:
            self._send_lighting()
        for which in sorted(self.dirty_keys):
            self._send_keys(which)
        if self.dirty_double and self.connected:
            self.worker.submit("double_enabled", self.double_enabled.get())

    def save_config(self):
        if not self.connected:
            self._toast("기기에 저장하려면 먼저 장치를 연결해 주세요.", warn=True)
            return
        if self.restoring or self.saving:
            return
        try:
            if self.saved_config is None:
                raise ValueError("먼저 키링 설정을 읽어와 주세요.")
            snapshot = deepcopy(self.saved_config)
            for which in self.dirty_keys:
                updated = self._key_settings(which)
                key_commands(which, updated)
                if which == 1:
                    snapshot.single = updated
                else:
                    snapshot.double = updated
            if self.dirty_lighting:
                snapshot.lighting = self._lighting_settings()
                lighting_commands(snapshot.lighting)
            if self.dirty_double:
                snapshot.double_click_enabled = self.double_enabled.get()
        except ValueError as exc:
            messagebox.showwarning("잘못된 입력", str(exc))
            return
        self._flush_edits()
        self.saving = True
        self.save_button.configure(state="disabled")
        self.reload_button.configure(state="disabled")
        self.worker.submit("save", (self.edit_generation, snapshot))
        self._toast("EEPROM 저장 명령을 전송하는 중입니다…")

    def _show_config(self, config: DeviceConfig):
        self._cancel_edits()
        self.loading = True
        settings = config.lighting
        for name, var in self.lighting_vars.items():
            var.set(getattr(settings, name))
        self.lighting_mode.set(LIGHT_MODES.get(settings.mode, LIGHT_LABELS[0]))
        self.double_enabled.set(config.double_click_enabled)
        for which, item in ((1, config.single), (2, config.double)):
            self.key_modes[which].set(KEY_MODES.get(item.mode, MODE_LABELS[0]))
            for var, code in zip(self.key_values[which], item.keys):
                var.set(VALUE_TO_KEY.get(code, "없음"))
            self.key_text[which].set(item.text)
            self._update_key_visibility(which)
        self._refresh_preview()
        self._update_motion_visibility()
        self.loading = False
        self._apply_double_ui_state()
        self.dirty_lighting = False
        self.dirty_keys.clear()
        self.dirty_double = False
        self.state_label.configure(
            text=f"연결됨  ·  펌웨어 v{config.version:02d}  ·  누른 횟수 {config.click_count:,}회",
            text_color=MINT,
        )
        if config.version != 1:
            self._toast("경고: 이 앱은 CaptainKey v01 프로토콜 기준입니다. 기능을 확인해 주세요.", warn=True)
        else:
            self._toast("장치 설정을 불러왔습니다. 변경 사항은 실시간으로 적용됩니다.")

    def _poll_events(self):
        try:
            while True:
                event, payload = self.worker.events.get_nowait()
                if event == "connected":
                    self.connected = True
                    self.saved_config = deepcopy(payload[1])
                    self.connect_button.configure(text="연결 해제", state="normal")
                    self.port_menu.configure(state="disabled")
                    self._show_config(payload[1])
                elif event == "disconnected":
                    self.connected = False
                    self.restoring = False
                    self.saving = False
                    self.reload_button.configure(state="normal")
                    self.save_button.configure(state="normal")
                    self.connect_button.configure(text="연결", state="normal")
                    self.port_menu.configure(state="normal")
                    self.state_label.configure(text="연결되지 않음", text_color=MUTED)
                elif event == "config":
                    self._show_config(payload)
                elif event == "restored":
                    generation, actual_config = payload
                    self.restoring = False
                    self.reload_button.configure(state="normal")
                    self.save_button.configure(state="normal")
                    self.connect_button.configure(state="normal")
                    # Refresh from the device's readback, not from a UI-only copy.
                    if generation == self.edit_generation:
                        self._show_config(actual_config)
                        self._toast("기기에 마지막으로 저장된 설정을 복원했습니다.")
                elif event == "saved":
                    generation, saved_snapshot = payload
                    self.saved_config = deepcopy(saved_snapshot)
                    self.saving = False
                    self.save_button.configure(state="normal")
                    self.reload_button.configure(state="normal")
                    if generation == self.edit_generation:
                        self.dirty_lighting = False
                        self.dirty_keys.clear()
                        self.dirty_double = False
                    self._toast("저장 명령을 전송했습니다. 장치가 완료 응답을 보내지는 않습니다.")
                elif event == "error":
                    self.restoring = False
                    self.saving = False
                    self.reload_button.configure(state="normal")
                    self.save_button.configure(state="normal")
                    self._toast(payload, warn=True)
                    self.connect_button.configure(state="normal")
        except queue.Empty:
            pass
        self.after(70, self._poll_events)

    def _on_close(self):
        self._cancel_edits()
        self.worker.shutdown()
        self.destroy()


if __name__ == "__main__":
    CaptainKeyKO().mainloop()
