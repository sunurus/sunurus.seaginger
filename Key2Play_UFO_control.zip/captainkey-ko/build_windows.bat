@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  set "PYRUN=py -3"
) else (
  set "PYRUN=python"
)
%PYRUN% --version >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Install Python 3 first: https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
%PYRUN% -m pip install -r requirements.txt pyinstaller
if errorlevel 1 (
  echo [ERROR] Dependency installation failed.
  pause
  exit /b 1
)
%PYRUN% -m PyInstaller --noconfirm --clean --onefile --windowed --name CaptainKey-KO --icon icon.ico --add-data "icon.ico;." app.py
if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)
echo.
echo SUCCESS: dist\CaptainKey-KO.exe
pause
