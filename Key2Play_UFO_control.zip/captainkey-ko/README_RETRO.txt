Key2Play RETRO Windows edition
기존 CaptainKey 통신 기능 유지, 디자인 및 한글 안내 수정.
실행: run_windows.bat
일반 키 입력은 PC 한영 상태를 따릅니다. 텍스트 자동 입력은 별도 제한이 있습니다.
