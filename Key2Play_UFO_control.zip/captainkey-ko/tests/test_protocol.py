import unittest

from protocol import (
    CONFIG_LENGTH, DeviceConfig, KeySettings, LightingSettings, SerialDevice,
    encode_command, encode_text, key_commands, lighting_commands, parse_config_packet,
)


def sample_raw():
    raw = [0] * CONFIG_LENGTH
    raw[0] = 1
    raw[2] = 1
    raw[3] = 2
    raw[4] = 2
    raw[10:17] = [226, 141, 125, 86, 0, 30, 1]
    raw[17:23] = [2, 232, 131, 100, 0, 0]
    raw[53:59] = [2, 131, 108, 0, 0, 0]
    raw[23:28] = list(map(ord, "Hello"))
    return raw


class ProtocolTests(unittest.TestCase):
    def test_command(self):
        self.assertEqual(encode_command(999, 2), b"{999:2}")
        self.assertEqual(encode_command(14, 0), b"{14:0}")
        with self.assertRaises(ValueError):
            encode_command(14, 256)

    def test_config_packet(self):
        raw = sample_raw()
        packet = "noise[" + ",".join(map(str, raw)) + "]\r\n"
        result = parse_config_packet(packet)
        self.assertEqual(result.version, 1)
        self.assertEqual(result.click_count, 258)
        self.assertTrue(result.double_click_enabled)
        self.assertEqual(result.lighting.red, 226)
        self.assertEqual(result.lighting.brightness, 86)
        self.assertEqual(result.single.keys[:3], [232, 131, 100])
        self.assertEqual(result.single.text, "Hello")
        self.assertEqual(result.double.keys[:2], [131, 108])

    def test_bad_packets(self):
        with self.assertRaisesRegex(ValueError, "응답"):
            parse_config_packet("<empty>")
        with self.assertRaisesRegex(ValueError, "길이"):
            parse_config_packet("[1,2,3]")

    def test_lighting_commands(self):
        values = lighting_commands(LightingSettings(1, 2, 3, 4, 2, 25, 5))
        self.assertEqual(values, [(10, 1), (11, 2), (12, 3), (13, 4),
                                  (14, 2), (15, 25), (16, 5), (999, 2)])

    def test_key_commands_and_text(self):
        values = key_commands(2, KeySettings(2, [131, 108, 0, 0, 0], "OK"))
        self.assertEqual(values[:6], [(53, 2), (54, 131), (55, 108), (56, 0), (57, 0), (58, 0)])
        self.assertEqual(values[6:9], [(59, 79), (60, 75), (61, 0)])
        self.assertEqual(len(values), 36)
        self.assertEqual(len(encode_text("")), 30)
        with self.assertRaises(ValueError):
            encode_text("한글")
        with self.assertRaises(ValueError):
            encode_text("a" * 31)

    def test_fake_serial_roundtrip(self):
        raw = sample_raw()
        payload = ("[" + ",".join(map(str, raw)) + "]").encode()

        class FakeSerial:
            def __init__(self, **kwargs):
                self.args = kwargs
                self.sent = []
                self.buffer = bytearray()

            def write(self, data):
                self.sent.append(data)
                if data == b"{999:1}":
                    self.buffer.extend(payload)

            def read(self, count):
                result = self.buffer[:count]
                del self.buffer[:count]
                return bytes(result)

            @property
            def in_waiting(self):
                return len(self.buffer)

            def reset_input_buffer(self):
                self.buffer.clear()

            def flush(self):
                pass

            def close(self):
                pass

        dev = SerialDevice("COM9", serial_factory=FakeSerial)
        config = dev.read_config()
        self.assertEqual(config.version, 1)
        self.assertEqual(dev.serial.args["baudrate"], 57600)
        dev.send([(10, 80), (999, 2)])
        dev.save()
        self.assertEqual(dev.serial.sent[-3:], [b"{10:80}", b"{999:2}", b"{999:0}"])


if __name__ == "__main__":
    unittest.main()
