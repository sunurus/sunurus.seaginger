@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  set "PYRUN=py -3"
) else (
  set "PYRUN=python"
)
%PYRUN% --version >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python 3 is required. Install it from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
%PYRUN% -m pip install -r requirements.txt
if errorlevel 1 (
  echo [ERROR] Dependency installation failed.
  pause
  exit /b 1
)
%PYRUN% app.py
if errorlevel 1 pause
