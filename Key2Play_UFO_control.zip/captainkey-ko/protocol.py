"""CaptainKey v01 / OneKeyBoard CH552 serial protocol.

Based on the published firmware protocol in Yamada-da/CaptainKey.
The app sends ASCII frames of the form ``{index:value}`` at 57,600 baud.

SPDX-License-Identifier: GPL-3.0-only
"""

from __future__ import annotations

from dataclasses import dataclass, field
import re
import time
from typing import Iterable


BAUD_RATE = 57600
CONFIG_LENGTH = 89
WRITE_GAP_SECONDS = 0.015
MAX_TEXT_LENGTH = 30


def _key_choices() -> dict[str, int]:
    result = {
        "없음": 0,
        "왼쪽 Ctrl": 128, "왼쪽 Shift": 129, "왼쪽 Alt": 130, "왼쪽 Win": 131,
        "오른쪽 Ctrl": 132, "오른쪽 Shift": 133, "오른쪽 Alt": 134,
        "오른쪽 Win": 135,
        "Enter": 176, "Esc": 177, "Backspace": 178, "Tab": 179,
        "Space": 32, "↑": 218, "↓": 217, "←": 216, "→": 215,
        "Insert": 209, "Delete": 212, "Home": 210, "End": 213,
        "Page Up": 211, "Page Down": 214,
        "볼륨 +": 230, "볼륨 -": 231, "음소거": 232,
        "재생 / 일시정지": 233, "이전 곡": 234, "다음 곡": 235,
    }
    result.update({c: ord(c.lower()) for c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"})
    result.update({str(n): ord(str(n)) for n in range(10)})
    return result


KEY_CHOICES = _key_choices()
VALUE_TO_KEY = {value: name for name, value in KEY_CHOICES.items()}
KEY_MODES = {
    0: "단일 키",
    1: "즉시 실행 조합",
    2: "누르는 동안 조합",
    3: "텍스트 입력",
}
LIGHT_MODES = {0: "고정 색상", 1: "숨쉬기", 2: "무지개 순환"}


@dataclass
class LightingSettings:
    red: int = 255
    green: int = 255
    blue: int = 255
    brightness: int = 255
    mode: int = 2
    interval: int = 30
    step: int = 1


@dataclass
class KeySettings:
    mode: int = 0
    keys: list[int] = field(default_factory=lambda: [0] * 5)
    text: str = ""


@dataclass
class DeviceConfig:
    version: int
    click_count: int
    double_click_enabled: bool
    lighting: LightingSettings
    single: KeySettings
    double: KeySettings


def encode_command(index: int, value: int) -> bytes:
    if not (0 <= index <= 999 and 0 <= value <= 255):
        raise ValueError("명령의 인덱스 또는 값이 유효하지 않습니다.")
    return f"{{{index}:{value}}}".encode("ascii")


def parse_config_packet(data: bytes | bytearray | str) -> DeviceConfig:
    decoded = data.decode("ascii", errors="ignore") if isinstance(data, (bytes, bytearray)) else data
    match = re.search(r"\[([\d,\s]+)\]", decoded)
    if match is None:
        raise ValueError("장치의 설정 응답을 찾지 못했습니다.")
    raw = [int(x.strip()) for x in match.group(1).split(",")]
    if len(raw) < CONFIG_LENGTH:
        raise ValueError(f"설정 길이가 너무 짧습니다. ({len(raw)}/{CONFIG_LENGTH})")
    if any(not 0 <= x <= 255 for x in raw):
        raise ValueError("장치에서 잘못된 설정 값이 전달되었습니다.")

    def parse_key(mode_index: int, start: int, text_start: int) -> KeySettings:
        chars = []
        for code in raw[text_start:text_start + MAX_TEXT_LENGTH]:
            if code in (0, 255):
                break
            chars.append(chr(code))
        return KeySettings(raw[mode_index], list(raw[start:start + 5]), "".join(chars))

    return DeviceConfig(
        version=raw[0],
        click_count=(raw[2] << 8) | raw[3],
        double_click_enabled=raw[4] == 2,
        lighting=LightingSettings(
            red=raw[10], green=raw[11], blue=raw[12], brightness=raw[13],
            mode=raw[14], interval=raw[15], step=raw[16],
        ),
        single=parse_key(17, 18, 23),
        double=parse_key(53, 54, 59),
    )


def _byte(value: int) -> int:
    number = int(value)
    if not 0 <= number <= 255:
        raise ValueError("값은 0~255 사이여야 합니다.")
    return number


def lighting_commands(settings: LightingSettings) -> list[tuple[int, int]]:
    if settings.mode not in LIGHT_MODES:
        raise ValueError("알 수 없는 LED 모드입니다.")
    if not 1 <= settings.step <= 50 or not 5 <= settings.interval <= 200:
        raise ValueError("변화 폭은 1~50, 간격은 5~200ms 사이여야 합니다.")
    return [
        (10, _byte(settings.red)), (11, _byte(settings.green)),
        (12, _byte(settings.blue)), (13, _byte(settings.brightness)),
        (14, settings.mode), (15, settings.interval), (16, settings.step),
        (999, 2),
    ]


def encode_text(text: str) -> list[int]:
    if len(text) > MAX_TEXT_LENGTH:
        raise ValueError("텍스트 입력은 영문·숫자 30자까지 지원합니다.")
    if any(ord(c) < 32 or ord(c) > 126 for c in text):
        raise ValueError("CH552 펌웨어는 한글이나 특수 유니코드 입력을 지원하지 않습니다. 영문 ASCII만 사용해 주세요.")
    return [ord(c) for c in text] + [0] * (MAX_TEXT_LENGTH - len(text))


def key_commands(which: int, settings: KeySettings) -> list[tuple[int, int]]:
    if which not in (1, 2) or settings.mode not in KEY_MODES:
        raise ValueError("알 수 없는 키 설정입니다.")
    if len(settings.keys) != 5:
        raise ValueError("조합키 슬롯은 5개여야 합니다.")
    mode_index, combo_start, text_start = (17, 18, 23) if which == 1 else (53, 54, 59)
    result = [(mode_index, settings.mode)]
    result.extend((combo_start + i, _byte(value)) for i, value in enumerate(settings.keys))
    result.extend((text_start + i, value) for i, value in enumerate(encode_text(settings.text)))
    return result


class SerialDevice:
    """Synchronous connection. Call from a worker thread, not the UI thread."""

    def __init__(self, port: str, serial_factory=None):
        if serial_factory is None:
            import serial
            serial_factory = serial.Serial
        self.serial = serial_factory(port=port, baudrate=BAUD_RATE, timeout=0.12, write_timeout=2)

    def close(self) -> None:
        self.serial.close()

    def send(self, commands: Iterable[tuple[int, int]]) -> None:
        for index, value in commands:
            self.serial.write(encode_command(index, value))
            time.sleep(WRITE_GAP_SECONDS)
        self.serial.flush()

    def read_config(self, timeout: float = 2.5) -> DeviceConfig:
        self.serial.reset_input_buffer()
        self.send([(999, 1)])
        deadline = time.monotonic() + timeout
        received = bytearray()
        while time.monotonic() < deadline:
            chunk = self.serial.read(max(1, self.serial.in_waiting))
            received.extend(chunk)
            if b"]" in received:
                return parse_config_packet(received)
            if len(received) > 8192:
                raise ValueError("장치 응답이 예상보다 깁니다.")
        raise TimeoutError("장치가 설정 정보를 반환하지 않았습니다. 펌웨어 및 COM 포트를 확인해 주세요.")

    def save(self) -> None:
        # Firmware sends no acknowledgment for EEPROM writes.
        self.send([(999, 0)])
