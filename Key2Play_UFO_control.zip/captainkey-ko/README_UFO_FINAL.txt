KEY2PLAY // UFO RETRO FINAL

Windows 95-style light, high-contrast interface for CaptainKey v01 (CH552).

CHANGES FROM Key2Play_Retro_Windows_Bold_v2:
- Sidebar subtitle changed to UFO.
- Fixed-color RGB presets only appear when fixed mode is selected.
- All RGB/brightness/effect slider tracks have a visible medium-gray background.
- COM and key option dropdown arrow buttons use bright lime backgrounds.
- Strong black text, square buttons, retro blue title strip and pink accents.
- Original protocol.py and serial worker remain unchanged.

HOW TO RUN:
1. Extract ZIP to a folder.
2. On Windows, double-click run_windows.bat. Python 3 and internet access for installing requirements are needed initially.
3. Connect CH552 device, refresh COM ports, select COM port, connect.
4. Changes are sent to the device automatically while connected.
5. Click '기기에 저장' to write settings to EEPROM.

NOTE: GUI and physical device were not verified on a Windows CH552 device in this build environment. Protocol unit tests (6) passed.
LICENSE: GPL-3.0-only (see LICENSE). Original CaptainKey project credited in README.md.
